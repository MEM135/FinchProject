package src;

public class Print {

	public static void print(int decimalNumber) {
		// @formatter:off
		String info = 
				"Decimal:" + " " + decimalNumber + " "
				+ "Binary:" + " " + Conversion.binary(decimalNumber) + " "
				+ "Octal:" + " " + Conversion.octal(decimalNumber) + " "
				+ "Hexadecimal:" + " " + Conversion.hexadecimal(decimalNumber);
		// @formatter:on

		System.out.println(info);
	}
}
