package src;

public class Conversion {

	private static final char HEXCHARS[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

	/**
	 * A RECURRENT METHOD IS IMPLEMENTED TO CONVERT THE DECIMAL INTEGER NUMBER TO AN OCTAL STRING
	 * 
	 * @param decimalNumber
	 * @return octal
	 */
	public static String octal(int decimalNumber) {
		if (decimalNumber == 0) {
			return "0";
		}
		String octal = "";
		while (decimalNumber > 0) {
			int rem = decimalNumber % 8;
			octal = rem + octal;
			decimalNumber = decimalNumber / 8;
		}
		return octal;
	}

	/**
	 * A RECURRENT METHOD IS IMPLEMENTED TO CONVERT THE DECIMAL INTEGER NUMBER TO A BINARY STRING
	 * 
	 * @param decimalNumber
	 * @return binary
	 */
	public static String binary(int decimalNumber) {
		if (decimalNumber == 0) {
			return "0";
		}
		String binary = "";
		while (decimalNumber > 0) {
			int rem = decimalNumber % 2;
			binary = rem + binary;
			decimalNumber = decimalNumber / 2;
		}
		return binary;
	}

	/**
	 * A RECURRENT METHOD IS IMPLEMENTED TO CONVERT THE DECIMAL INTEGER NUMBER TO AN HEXADECIMAL STRING
	 * 
	 * @param decimalNumber
	 * @return hexadecimal
	 */
	public static String hexadecimal(int decimalNumber) {
		int rem;
		String hex = "";
		while (decimalNumber > 0) {
			rem = decimalNumber % 16;
			hex = HEXCHARS[rem] + hex;
			decimalNumber = decimalNumber / 16;
		}
		return hex;
	}
}
