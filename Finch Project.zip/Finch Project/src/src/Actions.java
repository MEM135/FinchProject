package src;

import edu.cmu.ri.createlab.terk.robot.finch.Finch;

public class Actions {
	private Finch myFinch;

	public Actions() {
		myFinch = new Finch();
	}

	/** ACTION METHOD FOR FINCH MOVEMENT
	 * 
	 * @param decimalNumber
	 */
	public void move(int decimalNumber) {
		int speed = Math.max(decimalNumber, 50);
		int seconds = 2;
		if (Conversion.hexadecimal(speed).length() == 1) {
			seconds = 1;
		}
		myFinch.setWheelVelocities(speed, speed, seconds * 1000);
	}

	/** ACTION METHOD FOR FINCH LIGHTS
	 * 
	 * @param decimalNumber 
	 */
	public void light(int decimalNumber) {
		String lights = Conversion.binary(decimalNumber);
		for (int i = lights.length() - 1; i >= 0; i--) {
			char character = lights.charAt(i);
			if (character == '1') {
				myFinch.setLED(0, 255, 0, 2000);
			} else {
				myFinch.setLED(255, 0, 0, 2000);
			}
		}
	}
	
	/** ACTION METHOD FOR FINCH BUZZ
	 * 
	 * @param decimalNumber
	 */

	public void buzz(int decimalNumber) {
		int buzz = Integer.parseInt(Conversion.octal(decimalNumber));
		myFinch.buzz(buzz, 5000);
		myFinch.sleep(1000);
	}

	public void quit() {
		myFinch.quit();
	}

}