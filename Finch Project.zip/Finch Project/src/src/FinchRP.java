package src;

import javax.swing.JOptionPane;

public class FinchRP {

	public static void main(String[] arg) {
		boolean finish = false;

		Actions finchRobot = new Actions();
		while (!finish) {
			boolean numberOk = false;
			String decimalStr = JOptionPane.showInputDialog("Please, type a number between 0 and 255: ");
			try {
				int decimalNumber = Integer.parseInt(decimalStr);
				if (decimalNumber >= 0 && decimalNumber <= 255) {
					numberOk = true;
					Print.print(decimalNumber);

					String answer = JOptionPane.showInputDialog("Do you want to add an action?");
					if (answer.equalsIgnoreCase("yes")) {
						// Speed+Movement
						finchRobot.move(decimalNumber);

						// Lights
						finchRobot.light(decimalNumber);

						// Buzz
						finchRobot.buzz(decimalNumber);
					}
				}else {
					System.err.println("Please, type a number between 0 and 255");
				}
			} catch (NumberFormatException e) {
				System.err.println("No input number\n");
			} finally {
				if (numberOk || decimalStr == null) {
					String end = JOptionPane.showInputDialog("If you want to finish the program, type 'quit', other wise type 'no' ");
					if (end != null && end.equalsIgnoreCase("quit")) {
						finish = true;
					}
				}
			}
		}
		finchRobot.quit();
	}
}